﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    class Vegetable : Food
    {
        public Vegetable(int quantity)
        {
            this.Quantity = quantity;
        }
    }
}
