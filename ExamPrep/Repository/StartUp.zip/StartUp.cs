﻿using System;

namespace Repository
{
    public class StartUp
    {
        public static void Main()
        {
            DateTime a = new DateTime(2009, 05, 04);
        }
    }
}
