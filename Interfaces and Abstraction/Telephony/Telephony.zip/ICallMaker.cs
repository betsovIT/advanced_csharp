﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ICallMaker
    {
        void Call(string number);
    }
}
