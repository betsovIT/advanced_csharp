﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy
{
    interface IAddCollection
    {
        int Add(string element);
    }
}
