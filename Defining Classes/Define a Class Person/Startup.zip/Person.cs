﻿namespace DefiningClasses
{
    public class Person
    {
        public string Name { get; private set; }
        public int Age { get; private set; }
    }
}
