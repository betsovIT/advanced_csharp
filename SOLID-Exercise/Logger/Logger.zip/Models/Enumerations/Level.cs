﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Models.Enumerations
{
    public enum Level
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
